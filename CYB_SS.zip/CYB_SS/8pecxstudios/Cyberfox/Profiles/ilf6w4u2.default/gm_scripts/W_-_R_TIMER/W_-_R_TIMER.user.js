// ==UserScript==
// @name        W - R TIMER
// @namespace   Violentmonkey Scripts
// @match       https://onlinebooking.sand.telangana.gov.in/Order/NEWBOOKING.aspx?*
// @grant       none
// @version     1.0
// @author      -
// @description 10/06/2022, 10:07:49
// ==/UserScript==
let timer2 = document.getElementById('lbltime')
let elm = document.createElement('label');
elm.id = 'counter';
elm.style = 'color: blue; font-weight: bold; font-size: 4rem; display: block;'
elm.innerHTML = 'Timer : 0';
document.querySelectorAll('.TopSearch')[0].appendChild(elm);
let oberser = new MutationObserver(function callback(mutations){
    document.getElementById('counter').innerHTML = document.getElementById('lbltime').innerHTML
    console.log(document.getElementById('lbltime').innerHTML)
})

oberser.observe(timer2, {childList: true})