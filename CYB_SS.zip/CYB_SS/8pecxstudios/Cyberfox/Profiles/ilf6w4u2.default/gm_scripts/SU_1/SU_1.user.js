// ==UserScript==
// @name         SU 1
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include      http://onlinebooking.sand.telangana.gov.in/O*
// @include      https://onlinebooking.sand.telangana.gov.in/O*
// @grant        GM_getValue
// @grant        GM_setValue
// ==/UserScript==

var search = "The service is unavailable";

(function() {
'use strict';
    if(document.body.innerHTML.indexOf(search) !=-1) {
        console.log("The service is unavailable. reloading");
    //    location.reload();
            window.location = "https://onlinebooking.sand.telangana.gov.in/Order/BOOKINGHOME.aspx";
    }
})()
