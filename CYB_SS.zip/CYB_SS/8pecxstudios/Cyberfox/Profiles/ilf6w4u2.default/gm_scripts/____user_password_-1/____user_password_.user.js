// ==UserScript==
// @name          ____user_password_
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://onlinebooking.sand.telangana.gov.in/Masters/Home.aspx
// @match        https://onlinebooking.sand.telangana.gov.in/MASTERS/HOME.ASPX
// @grant        none
// ==/UserScript==

(function() {
    $('.hometdtext input[type=text]').val("8121114405");
    $('.hometdtext input[type=password]').val("12345678")
SubmitsEncry('8080808070808080');
    $('#ccMain_txtEnterCode').focus();
})()