// ==UserScript==
// @name            New Booking
// @namespace       https://workspace.tramvm.com/
// @version         5.3
// @description     Open new booking
// @author          workspace.gold@gmail.com
// @match           https://onlinebooking.sand.telangana.gov.in/Order/BOOKINGHOME.aspx
// ==/UserScript==

(function () {
    'use strict';
    document.querySelector(".menuH").querySelectorAll("li")[0].querySelector("a").click();
})();
                