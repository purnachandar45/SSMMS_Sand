// ==UserScript==
// @name         W - payment Error
// @namespace    http://tampermonkey.net/
// @version      2024-03-05
// @description  try to take over the world!
// @author       You
// @match        https://secure.payu.in/_payment
// @grant        none
// ==/UserScript==

(function() {
 if (window.location == "https://secure.payu.in/_payment")
 {
     window.location.reload();
 }
})();
