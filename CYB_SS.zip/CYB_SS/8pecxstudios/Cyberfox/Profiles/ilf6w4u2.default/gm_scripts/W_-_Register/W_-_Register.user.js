// ==UserScript==
// @name         W - Register
// @namespace    https://tracker.space.com/
// @version      4.0
// @description  auto captcha ssmms login form.
// @author       teamtracker@gmail.com
// @match        https://onlinebooking.sand.telangana.gov.in/*
// @grant        none
// ==/UserScript==

(function auto_submit_Register() {
        var timer = setInterval(function () {
            if (document.getElementById("lbltime").innerHTML == "Timer : 0") {
                clearInterval(timer);
                //$("#btnRegister").click();
                CallSMSFunc();
            }
    }, 1550);
})();