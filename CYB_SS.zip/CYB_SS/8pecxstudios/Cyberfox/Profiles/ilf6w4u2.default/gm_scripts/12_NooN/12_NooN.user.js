// ==UserScript==
// @name        12 NooN
// @namespace   The King
// @include     https://onlinebooking.sand.telangana.gov.in/MASTERS/UPTIME.ASPX
// @version     1
// @grant       none
// ==/UserScript==

(function() {
    'use strict';

    function loadPageAt(time) {
var timeFragments = time.split(":");
var timeToOpen = new Date();
var intervalId;
timeToOpen.setHours(parseInt(timeFragments[0]));
timeToOpen.setMinutes(parseInt(timeFragments[1]));
timeToOpen.setSeconds(timeFragments[2]);
timeToOpen = timeToOpen.getTime();
intervalId = setInterval(function() {
console.log("checking..");
if(timeToOpen < new Date().getTime() ) {
clearInterval(intervalId);
window.location =
"https://onlinebooking.sand.telangana.gov.in/Masters/Home.aspx";
}
},1);
}
    loadPageAt("11:59:59");
})();