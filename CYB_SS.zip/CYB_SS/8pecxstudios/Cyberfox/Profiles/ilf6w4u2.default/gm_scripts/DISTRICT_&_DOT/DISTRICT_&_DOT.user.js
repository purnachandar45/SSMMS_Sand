// ==UserScript==
// @name        DISTRICT & DOT
// @namespace   http://tampermonkey.net/
// @match       https://onlinebooking.sand.telangana.gov.in/*
// @grant       none
// @version     2.0
// @author      Workspace
// @description Select District
// ==/UserScript==

(function() {
    'use strict';
    $('.Dropdown').val('27').change()
    setTimeout(function(){
$('#ccMain_ddlsandpurpose').val('2').change();
    },0)
})();
        
var intId = setInterval(function(){    
for(var i=0;i<40;i++){
    var data = document.getElementsByClassName("GridviewScrollItem")[i].cells[2].innerHTML;
    if( data.indexOf("Annaram Upstream-1") != -1) {        
        $("input[type='radio']")[i].click();
        clearInterval(intId);
        break;
    }

}},0);