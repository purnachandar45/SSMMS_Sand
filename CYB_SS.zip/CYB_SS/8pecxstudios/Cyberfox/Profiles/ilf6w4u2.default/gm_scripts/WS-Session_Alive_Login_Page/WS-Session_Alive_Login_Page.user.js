// ==UserScript==
// @name         WS-Session Alive Login Page
// @version      1.2
// @description  Session Active For SSMMS LOGIN
// @author       DONT VIRAL THIS
// @match        https://onlinebooking.sand.telangana.gov.in/Masters/Home.aspx
// @match        https://onlinebooking.sand.telangana.gov.in/MASTERS/HOME.ASPX
// @grant        none
// ==/UserScript==

(function () {
'use strict';

function session_keep_alive() {
console.log("WS Session alive keeper loaded!");
console.log("v1.0");

var timer = function () {
var interval = setInterval(function () {
var now = new Date();
var urls = ["https://onlinebooking.sand.telangana.gov.in/Scripts/jquery-1.9.0.min.js", "https://onlinebooking.sand.telangana.gov.in/Images/ErrorSymbol.png", "https://onlinebooking.sand.telangana.gov.in/Images/TS-LOGO.png"]

var random_boolean = Math.random();
var endpoint = "";
if (random_boolean > 0.7) {
endpoint = urls[0] + "?t=" + now.getHours() + now.getMinutes() + now.getSeconds();
} else if (random_boolean > 0.3) {
endpoint = urls[1] + "?t=" + now.getHours() + now.getMinutes() + now.getSeconds();
} else {
endpoint = urls[2] + "?t=" + now.getHours() + now.getMinutes() + now.getSeconds();
}

$.get(endpoint, function (data) {
console.log(endpoint);
});

}, 30000);
};
timer();

}
setTimeout(session_keep_alive, 30000);
})();