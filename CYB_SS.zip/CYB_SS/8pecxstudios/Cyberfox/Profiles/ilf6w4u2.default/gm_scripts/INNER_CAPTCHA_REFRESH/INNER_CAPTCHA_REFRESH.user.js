// ==UserScript==
// @name         INNER CAPTCHA REFRESH
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://onlinebooking.sand.telangana.gov.in/*
// @match        https://onlinebooking.sand.telangana.gov.in/Order/*
// @match        https://onlinebooking.sand.telangana.gov.in/Order/NEWBOOKING.aspx?
// @run-at       document-end
// @grant        none
// ==/UserScript==
(function() {
        var timer = setInterval(function () {
            if (document.getElementById("lbltime").innerHTML == "Timer : 115") {
                clearInterval(timer);
                setTimeout(function () {
                $("#lnkCRefresh").click();
                }, 1090);
            }
    }, 100);
})();