// ==UserScript==
// @name         District_&_Bubble
// @version      0.1
// @author       You
// @match        https://onlinebooking.sand.telangana.gov.in/*
// @match        https://sand.telangana.gov.in/TSSandPortal/Masters/Home.aspx
// @grant        none
// ==/UserScript==

(function() {'use strict';var intId = setInterval(function(){for(var i=0;i<90;i++){ if(document.getElementsByClassName("GridviewScrollItem")
    [i].cells[2].innerHTML=="Chunchupally-IV (SBA),B-5")

{ $("input[type=radio]")[i].click()}clearInterval(intId);}},0);})();



(function() {
    'use strict';

setTimeout(function() {
javascript: {
    $('#ccMain_ddlsandpurpose').val(2);
    $('#ccMain_rbtPG_2').click();
    $('#ccMain_ddldeldistrict').val(41);
    $('#ccMain_ddldelMandal').append('<option value ="04">Vikarabad</option>');
    $('#ccMain_ddldelvillage').append('<option value ="031">Vikarabad</option>');
    document.getElementById("ccMain_ddldelMandal").value = "04";
    document.getElementById("ccMain_ddldelvillage").value = "031";
    WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("", "", false, "", "", false, false));
    void(0);
}
    }, 5000);
    })();

$(document).ready(function($) {
$('select[class="Dropdown"]').val('27');
}).call(PopulateGrid(0), jQuery);
